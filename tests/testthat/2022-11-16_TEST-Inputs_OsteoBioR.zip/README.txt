contains no model output
