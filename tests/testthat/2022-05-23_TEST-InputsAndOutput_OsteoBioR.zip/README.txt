test: data, model inputs and output
